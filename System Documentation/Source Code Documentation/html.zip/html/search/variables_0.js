var searchData=
[
  ['afms',['AFMS',['../bot_main_8ino.html#a7e8151031cf9a913ec4a28a5f56ed7c0',1,'botMain.ino']]],
  ['algorithm',['algorithm',['../bot_main_8ino.html#a92d3a0b679d3adc3b4b513f8e26e7f4c',1,'botMain.ino']]],
  ['anchors',['anchors',['../bot_main_8ino.html#a40781b19eab312bdfa08034230bb64d1',1,'botMain.ino']]],
  ['anchors_5fx',['anchors_x',['../bot_main_8ino.html#ae6db46a34ef60ff16acd025bfcaed344',1,'botMain.ino']]],
  ['anchors_5fy',['anchors_y',['../bot_main_8ino.html#acc43d1150756410770334dba55d59783',1,'botMain.ino']]]
];
