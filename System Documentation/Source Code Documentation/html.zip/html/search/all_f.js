var searchData=
[
  ['sendbtdata',['sendBTData',['../bot_main_8ino.html#a9c7adb3a38b0de84b613e166666630d6',1,'botMain.ino']]],
  ['sensorangle_5f',['sensorAngle_',['../class_obstacle_sensor.html#a348cf9783f793442c56f1b34e3515dbb',1,'ObstacleSensor']]],
  ['sensorgridangle_5f',['sensorGridAngle_',['../class_obstacle_sensor.html#a063ee604be2c3b6ed8034cafedda0c3d',1,'ObstacleSensor']]],
  ['servo1',['servo1',['../bot_main_8ino.html#ac5d2bea44c6318454db0e2639a4efe95',1,'botMain.ino']]],
  ['setanchorsmanual',['setAnchorsManual',['../bot_main_8ino.html#ad401219e4b701bed928f7caafd7108f2',1,'botMain.ino']]],
  ['setup',['setup',['../bot_main_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'botMain.ino']]],
  ['sidesclear',['sidesClear',['../class_navigator.html#a1d670758a59db4df8ea64110ae2979d1',1,'Navigator']]],
  ['sonar_5f',['sonar_',['../class_obstacle_sensor.html#a761a011e9009edaaee103d9bafceba14',1,'ObstacleSensor']]],
  ['soundcm_5f',['soundcm_',['../class_obstacle_sensor.html#ae6d0b250f37a34d04103d43e4e4e0082',1,'ObstacleSensor']]]
];
