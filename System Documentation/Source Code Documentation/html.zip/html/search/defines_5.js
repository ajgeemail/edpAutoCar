var searchData=
[
  ['max_5fsensor_5fdelay',['MAX_SENSOR_DELAY',['../_new_ping_8h.html#a016c1fb76dcd811ed0b10fddad7e8860',1,'NewPing.h']]],
  ['max_5fsensor_5fdistance',['MAX_SENSOR_DISTANCE',['../_new_ping_8h.html#a066008eaba26c8638c448b56bc6e1ea4',1,'NewPing.h']]]
];
