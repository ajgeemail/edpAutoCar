var searchData=
[
  ['x_5floc',['x_loc',['../bot_main_8ino.html#a9d3947cda218cfaa85dfef513d39c73c',1,'botMain.ino']]],
  ['x_5floc_5fprev',['x_loc_prev',['../bot_main_8ino.html#ac5e6eb62b1453be293f043e996637130',1,'botMain.ino']]],
  ['xdistcomp_5f',['xDistComp_',['../class_obstacle_sensor.html#ac13b7eab4b79c41cb51058c0351d1ae6',1,'ObstacleSensor']]],
  ['xpos_5f',['xPos_',['../class_obstacle_sensor.html#aae4a515b967900605f9f4716112a8dad',1,'ObstacleSensor']]],
  ['xposstart',['xPosStart',['../bot_main_8ino.html#ad7faed3f920e2a86bd4d0462a8d907ea',1,'botMain.ino']]],
  ['xposstartnav',['xPosStartNav',['../_navigator_8cpp.html#a5249124be298aa1e884d307b76e162e1',1,'Navigator.cpp']]],
  ['xpostarget',['xPosTarget',['../bot_main_8ino.html#a9ff06ce163dbdadcbad347cd3f4fd6b1',1,'botMain.ino']]],
  ['xpostargetnav',['xPosTargetNav',['../_navigator_8cpp.html#ad53b8710923ca95ae0375a0149d82ad1',1,'Navigator.cpp']]]
];
