var searchData=
[
  ['sendbtdata',['sendBTData',['../bot_main_8ino.html#a9c7adb3a38b0de84b613e166666630d6',1,'botMain.ino']]],
  ['setanchorsmanual',['setAnchorsManual',['../bot_main_8ino.html#ad401219e4b701bed928f7caafd7108f2',1,'botMain.ino']]],
  ['setup',['setup',['../bot_main_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'botMain.ino']]],
  ['sidesclear',['sidesClear',['../class_navigator.html#a1d670758a59db4df8ea64110ae2979d1',1,'Navigator']]]
];
