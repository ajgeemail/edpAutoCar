var searchData=
[
  ['ping_5fmedian_5fdelay',['PING_MEDIAN_DELAY',['../_new_ping_8h.html#ad5b13211068dba41dd4708611eacd046',1,'NewPing.h']]],
  ['ping_5foverhead',['PING_OVERHEAD',['../_new_ping_8h.html#abf806517ed5c333ebae5f6f04fb16079',1,'PING_OVERHEAD():&#160;NewPing.h'],['../_new_ping_8h.html#abf806517ed5c333ebae5f6f04fb16079',1,'PING_OVERHEAD():&#160;NewPing.h']]],
  ['ping_5ftimer_5foverhead',['PING_TIMER_OVERHEAD',['../_new_ping_8h.html#a98683564d6fcb3e53d44f23b65c1d1a5',1,'PING_TIMER_OVERHEAD():&#160;NewPing.h'],['../_new_ping_8h.html#a98683564d6fcb3e53d44f23b65c1d1a5',1,'PING_TIMER_OVERHEAD():&#160;NewPing.h']]]
];
