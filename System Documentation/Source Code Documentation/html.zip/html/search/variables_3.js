var searchData=
[
  ['data',['DATA',['../common_8h.html#ace45c8c944a852d4990f5f8f87b2335e',1,'DATA():&#160;common.h'],['../_navigator_8h.html#ace45c8c944a852d4990f5f8f87b2335e',1,'DATA():&#160;Navigator.h']]],
  ['dimension',['dimension',['../bot_main_8ino.html#a1a8a8235879363159315091a1daed72f',1,'botMain.ino']]],
  ['distance_5f',['distance_',['../class_obstacle_sensor.html#ac38c343c22e4f8afbde0b04b928f07cc',1,'ObstacleSensor']]],
  ['duration_5f',['duration_',['../class_obstacle_sensor.html#aa206d6a1ab58f0a98fe00107b80cf764',1,'ObstacleSensor']]]
];
