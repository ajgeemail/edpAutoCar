var searchData=
[
  ['nav',['nav',['../bot_main_8ino.html#aa40b8d55e3cb08134da6fa492346bcd2',1,'botMain.ino']]],
  ['navptr_5f',['navPtr_',['../class_obstacle_detection.html#aa68ee81b360a24f6977480aab44f5650',1,'ObstacleDetection']]],
  ['num_5fanchors',['num_anchors',['../bot_main_8ino.html#af45be5355306144528cdfb308bd00859',1,'botMain.ino']]],
  ['num_5fto_5favg',['num_to_avg',['../bot_main_8ino.html#a1a7877b55ae0baf9e8b9250195dd3f81',1,'botMain.ino']]]
];
