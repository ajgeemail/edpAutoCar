var searchData=
[
  ['cgk_5fback_5flittle',['cgk_back_little',['../bot_main_8ino.html#a561c3c1ac229de5ea299ea71e1b1a797',1,'botMain.ino']]],
  ['cgk_5fback_5fone',['cgk_back_one',['../bot_main_8ino.html#a91243a6041a1ec2fce66d4c8cfd2a139',1,'botMain.ino']]],
  ['cgk_5fbrake_5ftime',['cgk_brake_time',['../bot_main_8ino.html#a7ec3cca0a6256b97b26506e7c3d2f793',1,'botMain.ino']]],
  ['cgk_5ffirst_5fangle_5fdivider',['cgk_first_angle_divider',['../bot_main_8ino.html#acb1471feb53affb97626965870071b54',1,'botMain.ino']]],
  ['cgk_5ffwd_5fend_5fturn',['cgk_fwd_end_turn',['../bot_main_8ino.html#a24a75c74d8b88fb34b3753881d8a18de',1,'botMain.ino']]],
  ['cgk_5ffwd_5flittle',['cgk_fwd_little',['../bot_main_8ino.html#a5319965a94b5c8e64061d2999f513ec6',1,'botMain.ino']]],
  ['cgk_5ffwd_5fone',['cgk_fwd_one',['../bot_main_8ino.html#a49bdb35c116d5940c7ee0698d8508043',1,'botMain.ino']]],
  ['cgk_5fmotor_5fspeed',['cgk_motor_speed',['../bot_main_8ino.html#a73b8bce90bbda89fe2c9cace8ebd7467',1,'botMain.ino']]],
  ['cgk_5fstraight',['cgk_straight',['../bot_main_8ino.html#a5bb179d9202804dccaa9f18aa453df29',1,'botMain.ino']]],
  ['cgk_5fturn_5fdelay',['cgk_turn_delay',['../bot_main_8ino.html#a3e81c768ee699008e7e551d8ebb140f2',1,'botMain.ino']]]
];
