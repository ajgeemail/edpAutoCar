var searchData=
[
  ['basicavgamt',['basicAvgAmt',['../bot_main_8ino.html#a5f0abc26cd1e11941fb44168ea055b1a',1,'botMain.ino']]],
  ['bias_5f',['bias_',['../class_obstacle_sensor.html#ad47c1a66f4d8eb28e239f3ae1c34f873',1,'ObstacleSensor']]]
];
